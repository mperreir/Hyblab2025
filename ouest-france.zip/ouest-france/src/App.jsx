// src/App.jsx
import React from 'react';
import { useState, useEffect } from 'react';
import { scrollToSection } from './utils';

import Home from './screens/Home';
import ChoosePlayer from './screens/ChoosePlayer/ChoosePlayer';
import Article from './screens/Article';
import Quiz from './screens/Quiz';

const App = () => {

  const baseUrl = `${window.location.origin}/ouest-france/api`;

  const [quizData, setQuizData] = useState(null);
  const [articleData, setArticleData] = useState(null)

  // Gestion du clic sur un bouton dans ChoosePlayer
  const handleQuizSelection = async (quizKey) => {

    //fetch l'api
    const quizFetch = await fetch(`${baseUrl}/${quizKey}/quiz`)
    const quizJson = await quizFetch.json()

    const articleFetch = await fetch(`${baseUrl}/${quizKey}/article`)
    const articleJson = await articleFetch.json()

    setQuizData(quizJson);
    setArticleData(articleJson);
  };

  useEffect(() => {
    if (quizData && articleData) {
      scrollToSection('quiz0');
    }
  }, [quizData, articleData]);

  return (
    <div className='app-container h-screen w-full overflow-y-scroll snap-y snap-mandatory [scroll-behavior:smooth]'>
      <Home />
      <ChoosePlayer onSelectPlayer={handleQuizSelection} />
      {quizData && (
        <>
          <Quiz data={quizData} />
          <Article data={articleData}/>
        </>
        )}
    </div>
  );
};

export default App;
